import { Users, DollarSign, Activity, TrendingUp } from 'lucide-react';
import type { ReactNode } from 'react';
import Sidebar from '@/components/Sidebar';
import DynamicCharts from '@/components/DynamicCharts';
import type { ChartData } from 'chart.js';

const revenueData: ChartData<'line'> = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      label: 'Revenue ($)',
      data: [12000, 19000, 15000, 21000, 24000, 28000],
      borderColor: 'rgb(75, 192, 192)',
      backgroundColor: 'rgba(75, 192, 192, 0.2)',
      fill: true,
      tension: 0.4,
    },
  ],
};

const signupData: ChartData<'bar'> = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      label: 'New Users',
      data: [200, 450, 350, 520, 480, 610],
      backgroundColor: 'rgba(54, 162, 235, 0.7)',
    },
  ],
};

const expenseData: ChartData<'doughnut'> = {
  labels: ['Salaries', 'Marketing', 'Infrastructure', 'Others'],
  datasets: [
    {
      data: [45000, 22000, 12000, 8000],
      backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
    },
  ],
};

const transactions = [
  { id: 1, customer: 'Alice Johnson', amount: '$1,200', status: 'Completed', date: '2026-05-10' },
  { id: 2, customer: 'Bob Smith', amount: '$850', status: 'Pending', date: '2026-05-09' },
  { id: 3, customer: 'Carol White', amount: '$2,300', status: 'Completed', date: '2026-05-08' },
  { id: 4, customer: 'Dave Lee', amount: '$430', status: 'Failed', date: '2026-05-07' },
  { id: 5, customer: 'Eva Brown', amount: '$1,750', status: 'Completed', date: '2026-05-06' },
];

const statusStyles: Record<string, string> = {
  Completed: 'bg-green-100 text-green-800',
  Pending: 'bg-yellow-100 text-yellow-800',
  Failed: 'bg-red-100 text-red-800',
};

interface StatCardProps {
  title: string;
  value: string;
  change: string;
  icon: ReactNode;
}

function StatCard({ title, value, change, icon }: StatCardProps) {
  return (
    <article className="rounded-lg bg-white p-4 shadow">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-gray-600">{title}</p>
        <span className="text-blue-600" aria-hidden="true">{icon}</span>
      </div>
      <p className="mt-2 text-2xl font-bold text-gray-900">{value}</p>
      <p className="mt-1 text-sm font-medium text-green-700">
        <span className="sr-only">Change: </span>{change}
      </p>
    </article>
  );
}

export default function DashboardPage() {
  return (
    <div className="flex h-screen bg-gray-100">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded focus:bg-white focus:px-4 focus:py-2 focus:text-blue-700 focus:shadow-lg focus:outline-none"
      >
        Skip to main content
      </a>

      <Sidebar />

      <main
        id="main-content"
        tabIndex={-1}
        aria-label="FinTech Dashboard main content"
        className="flex-1 overflow-y-auto p-6 focus-visible:outline-none"
      >
        <h1 className="mb-6 text-2xl font-bold text-gray-900">Dashboard</h1>

        <section aria-labelledby="kpi-heading" className="mb-6">
          <h2 id="kpi-heading" className="sr-only">Key performance indicators</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              title="Total Users"
              value="12,480"
              change="+12.5%"
              icon={<Users size={20} aria-hidden="true" />}
            />
            <StatCard
              title="Revenue"
              value="$48,500"
              change="+8.2%"
              icon={<DollarSign size={20} aria-hidden="true" />}
            />
            <StatCard
              title="Transactions"
              value="1,823"
              change="+15.3%"
              icon={<Activity size={20} aria-hidden="true" />}
            />
            <StatCard
              title="Growth"
              value="23.6%"
              change="+5.1%"
              icon={<TrendingUp size={20} aria-hidden="true" />}
            />
          </div>
        </section>

        <section aria-labelledby="charts-heading" className="mb-6">
          <h2 id="charts-heading" className="sr-only">Analytics charts</h2>
          <DynamicCharts
            revenueData={revenueData}
            signupData={signupData}
            expenseData={expenseData}
          />
        </section>

        <section aria-labelledby="transactions-heading">
          <div className="rounded-lg bg-white p-4 shadow">
            <h2
              id="transactions-heading"
              className="mb-4 text-lg font-semibold text-gray-800"
            >
              Recent Transactions
            </h2>
            <div className="overflow-x-auto">
              <table
                className="min-w-full text-left text-sm"
                aria-describedby="transactions-heading"
              >
                <caption className="sr-only">
                  Recent financial transactions, sorted by date — most recent first
                </caption>
                <thead>
                  <tr className="border-b bg-gray-50">
                    <th scope="col" className="px-4 py-2 font-semibold text-gray-700">
                      Customer
                    </th>
                    <th scope="col" className="px-4 py-2 font-semibold text-gray-700">
                      Amount
                    </th>
                    <th scope="col" className="px-4 py-2 font-semibold text-gray-700">
                      Status
                    </th>
                    <th scope="col" className="px-4 py-2 font-semibold text-gray-700">
                      Date
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((tx) => (
                    <tr key={tx.id} className="border-b last:border-none hover:bg-gray-50">
                      <td className="px-4 py-2 text-gray-900">{tx.customer}</td>
                      <td className="px-4 py-2 text-gray-900">{tx.amount}</td>
                      <td className="px-4 py-2">
                        <span
                          className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
                            statusStyles[tx.status] ?? 'bg-gray-100 text-gray-800'
                          }`}
                        >
                          {tx.status}
                        </span>
                      </td>
                      <td className="px-4 py-2 text-gray-600">{tx.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
