'use client';

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler,
  type ChartData,
} from 'chart.js';
import { Line, Bar, Doughnut } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler,
);

const BASE_OPTIONS = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { position: 'bottom' as const },
  },
};

interface DynamicChartsProps {
  revenueData: ChartData<'line'>;
  signupData: ChartData<'bar'>;
  expenseData: ChartData<'doughnut'>;
}

export default function DynamicCharts({
  revenueData,
  signupData,
  expenseData,
}: DynamicChartsProps) {
  return (
    <>
      <div className="mb-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm lg:col-span-2">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-xl font-semibold text-slate-950">Revenue Trend</h2>
              <p className="mt-1 text-sm text-slate-500">
                Monthly revenue performance over the last six months.
              </p>
            </div>
            <span className="rounded-full bg-slate-100 px-3 py-2 text-sm font-semibold text-slate-600">
              6 month view
            </span>
          </div>
          <div className="mt-6 h-[260px]">
            <Line
              data={revenueData}
              options={BASE_OPTIONS}
              role="img"
              aria-label="Line chart: monthly revenue from January ($12k) to June ($28k)"
            />
          </div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-xl font-semibold text-slate-950">Expense Breakdown</h2>
              <p className="mt-1 text-sm text-slate-500">Distribution of operating expenses.</p>
            </div>
            <span className="rounded-full bg-slate-100 px-3 py-2 text-sm font-semibold text-slate-600">
              2026 Q2
            </span>
          </div>
          <div className="mt-6 h-[260px]">
            <Doughnut
              data={expenseData}
              options={BASE_OPTIONS}
              role="img"
              aria-label="Doughnut chart: Salaries 45k, Marketing 22k, Infrastructure 12k, Others 8k"
            />
          </div>
        </div>
      </div>

      <div className="mb-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-xl font-semibold text-slate-950">User Signups</h2>
              <p className="mt-1 text-sm text-slate-500">New account signups each month.</p>
            </div>
            <span className="rounded-full bg-slate-100 px-3 py-2 text-sm font-semibold text-slate-600">
              Active growth
            </span>
          </div>
          <div className="mt-6 h-[320px]">
            <Bar
              data={signupData}
              options={BASE_OPTIONS}
              role="img"
              aria-label="Bar chart: monthly new user signups from January (200) to June (610)"
            />
          </div>
        </div>
      </div>
    </>
  );
}
