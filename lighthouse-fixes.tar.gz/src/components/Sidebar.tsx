'use client';

import { useState, useCallback } from 'react';
import {
  LayoutDashboard,
  TrendingUp,
  Users,
  DollarSign,
  Activity,
  Menu,
} from 'lucide-react';
import type { ReactNode } from 'react';

interface SidebarItemProps {
  icon: ReactNode;
  text: string;
  active?: boolean;
  sidebarOpen: boolean;
}

function SidebarItem({ icon, text, active, sidebarOpen }: SidebarItemProps) {
  return (
    <button
      type="button"
      aria-label={!sidebarOpen ? text : undefined}
      aria-current={active ? 'page' : undefined}
      className={`flex w-full items-center gap-3 rounded px-2 py-2 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 ${
        active ? 'bg-blue-800 font-medium' : 'hover:bg-blue-800/60'
      }`}
    >
      <span className="shrink-0" aria-hidden="true">{icon}</span>
      {sidebarOpen && <span>{text}</span>}
    </button>
  );
}

export default function Sidebar() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const toggleSidebar = useCallback(() => setSidebarOpen((prev) => !prev), []);

  return (
    <aside
      aria-label="Primary navigation"
      className={`${
        sidebarOpen ? 'w-64' : 'w-20'
      } flex flex-col bg-blue-900 p-4 text-white transition-all duration-300`}
    >
      <div className="mb-8 flex items-center justify-between">
        <span
          className={`text-xl font-bold${sidebarOpen ? '' : ' sr-only'}`}
        >
          FinDash
        </span>
        <button
          type="button"
          onClick={toggleSidebar}
          aria-label={sidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
          aria-expanded={sidebarOpen}
          className="rounded p-1 hover:bg-blue-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
        >
          <Menu size={20} aria-hidden="true" />
        </button>
      </div>

      <nav aria-label="Dashboard sections" className="flex-1 space-y-2">
        <SidebarItem
          icon={<LayoutDashboard size={18} />}
          text="Dashboard"
          active
          sidebarOpen={sidebarOpen}
        />
        <SidebarItem
          icon={<TrendingUp size={18} />}
          text="Analytics"
          sidebarOpen={sidebarOpen}
        />
        <SidebarItem
          icon={<Users size={18} />}
          text="Customers"
          sidebarOpen={sidebarOpen}
        />
        <SidebarItem
          icon={<DollarSign size={18} />}
          text="Revenue"
          sidebarOpen={sidebarOpen}
        />
        <SidebarItem
          icon={<Activity size={18} />}
          text="Reports"
          sidebarOpen={sidebarOpen}
        />
      </nav>
    </aside>
  );
}
